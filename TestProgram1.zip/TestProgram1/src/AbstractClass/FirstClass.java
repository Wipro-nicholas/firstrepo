package AbstractClass;

public class FirstClass extends Compartment{

	public FirstClass() {
		super();
	}
	
	public void notice(){
		System.out.println("First Class Compartment");
	}

}
