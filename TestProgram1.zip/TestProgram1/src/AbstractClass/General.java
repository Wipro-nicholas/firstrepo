package AbstractClass;

public class General extends Compartment{

	public General() {
		super();
	}
	public void notice(){
		System.out.println("General Compartment");
	}

}
