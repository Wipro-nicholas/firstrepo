package AbstractClass;

public class Luggage extends Compartment{

	public Luggage() {
		super();
	}
	public void notice(){
		System.out.println("Luggage Compartment");
	}

}
