package AbstractClass;

public abstract class Compartment {
	
	public Compartment(){
		notice();
	}


	public void notice(){
		System.out.println("Compartment");
	}
}
