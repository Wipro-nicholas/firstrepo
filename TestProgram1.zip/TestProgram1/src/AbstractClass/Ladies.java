package AbstractClass;

public class Ladies extends Compartment{

	public Ladies() {
		super();
	}
	public void notice(){
		System.out.println("Ladies Compartment");
	}
	
}
