package AbstractClass;

import java.util.Random;

public class TestCompartment {

	public static void main(String[] args){
		//First class = 0, Ladies = 1, General = 2, Luggage = 3
		
		Compartment c[] = new Compartment[10];
		Random r = new Random();
		for(int i=0; i<10; i++){
			int value = r.nextInt(4);
			switch(value){
			case 0:
				c[i] = new FirstClass();
				break;
			case 1:
				c[i] = new Ladies();
				break;
			case 2:
				c[i] = new General();
				break;
			case 3:
				c[i] = new Luggage();
				break;
			}
		}
	}
}
