package automobile.twoWheeler;

public class Hero extends automobile.Vehicle{

	private int speed;
	private boolean activeMusic = false;
	
	public Hero(int speed, boolean music){
		this.speed = speed;
		this.activeMusic = music;
	}
	
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public void radio(boolean music){
		this.activeMusic = music;
	}
	
	
}
