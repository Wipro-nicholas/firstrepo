package automobile.twoWheeler;

public class testCar {

	public static void main(String[] args){
		Hero hero = new Hero(15, false);
		Honda honda = new Honda(20, true);
	}
	
}
