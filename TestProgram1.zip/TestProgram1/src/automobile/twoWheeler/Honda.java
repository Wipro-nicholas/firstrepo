package automobile.twoWheeler;

public class Honda extends automobile.Vehicle{

	private int speed;
	private boolean activeMusic = false;
	
	public Honda(int speed, boolean music){
		this.speed = speed;
		this.activeMusic = music;
	}
	
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public void cdPlayer(boolean music){
		this.activeMusic = music;
	}
	
	
}
