package automobile;

public abstract class Vehicle {

	public Vehicle(){
		
	}
	
	public String getModelName(){
		return null;
	}
	
	public String getRegistrationNumber(){
		return null;

	}
	
	public String getOwnerName(){
		return null;

	}
}
