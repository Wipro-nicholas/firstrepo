package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSets {
	
	public static void main(String[] args){
	eight();
	}
	
	public static void one(){
		TreeSet ts = new TreeSet();
		ts.add("Blue");
		ts.add("yellow");
		ts.add("green");
		System.out.println(ts);
	}
	
	public static void two(){
		TreeSet ts = new TreeSet();
		ts.add("Blue");
		ts.add("yellow");
		ts.add("green");
		Iterator iterate;
		iterate = ts.iterator();
		System.out.println("Reversed Tree Set Data: ");
		while(iterate.hasNext()){
			System.out.println(iterate.next());
		}
	}
	
	public static void three(){
		TreeSet ts = new TreeSet();
		ts.add("Blue");
		ts.add("yellow");
		ts.add("green");
		Iterator iterate;
		iterate = ts.descendingIterator();
		System.out.println("Tree Set Data: ");
		while(iterate.hasNext()){
			System.out.println(iterate.next());
		}
	}
	
	public static void four(){
		TreeSet ts = new TreeSet();
		String last;
		String first;
		
		//treeset items are sorted and yellow is the last value (alphabetically)
		ts.add("Blue");
		ts.add("zxx");
		ts.add("Yellow");
		ts.add("green");
		ts.add("orange");

		
		first = (String) ts.first();
		last = (String) ts.last();
		System.out.println("First item: " + first);
		System.out.println("Last item: " + last);
	}
	
	public static void five(){
		TreeSet ts = new TreeSet();
		ts.add("Blue");
		ts.add("zxx");
		ts.add("Yellow");
		ts.add("green");
		ts.add("orange");
		
		int size = ts.size();
		System.out.println(size);
	}
	
	public static void six(){
		TreeSet ts = new TreeSet();
		Object first;
		
		ts.add("Blue");
		ts.add("zxx");
		ts.add("Yellow");
		ts.add("green");
		ts.add("orange");
		
		first = ts.last();
		System.out.println(ts);
		System.out.println(first);
		ts.remove(first);
		System.out.println(ts);
	}
	
	public static void seven(){
		TreeSet ts = new TreeSet();
		Object last;
		
		ts.add("Blue");
		ts.add("zxx");
		ts.add("Yellow");
		ts.add("green");
		ts.add("orange");
		
		last = ts.last();
		System.out.println(ts);
		System.out.println(last);
		ts.remove(last);
		System.out.println(ts);
	}
	
	public static void eight(){
		TreeSet ts = new TreeSet();
		Object search = "green";

		
		ts.add("Blue");
		ts.add("zxx");
		ts.add("Yellow");
		ts.add("green");
		ts.add("orange");
		
		ts.remove(search);
		System.out.println(ts);
	}
}
