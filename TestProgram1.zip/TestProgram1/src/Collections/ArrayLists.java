package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ArrayLists {
	
	public static void main(String[] args){
		nine();
	}
	
	public static void one(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		System.out.println(newList);
	}
	
	public static void two(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Green");
		newList.add(0, "Orange");
		System.out.println(newList);
	}
	
	public static void three(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		String blue = newList.get(0);
		System.out.println(blue);
	}
	
	public static void four(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		newList.set(1, "green");
		System.out.println(newList);
	}
	
	public static void five(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		newList.remove(1);
		System.out.println(newList);
	}
	
	public static void six(){
		ArrayList<String> newList = new ArrayList<String>();
		String search = "Orange";
		int result;
		String stringResult;
		newList.add("Orange");
		
		result = newList.indexOf(search);
		System.out.println(result);
		stringResult = newList.get(0);
		System.out.println(stringResult);
	}
	
	public static void seven(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		
		Comparator<? super String> c = null;
		newList.sort(c);
		System.out.println(newList);
	}
	
	public static void eight(){
		ArrayList<String> newList = new ArrayList<String>();
		ArrayList<String> copyList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		
		copyList = newList;
		System.out.println("Original List: " + newList);
		System.out.println("CopyList: " + copyList);
	}
	
	public static void nine(){
		ArrayList<String> newList = new ArrayList<String>();
		newList.add("Blue");
		newList.add("Yellow - sucks");
		newList.add("Green");
		newList.add("Purple");
		
		Collections.reverse(newList);
		System.out.println(newList);
	}
}
