package Collections;

import java.util.HashMap;

public class HashMaps {
	
	public static void main(String[] args){
		five();
	}
	
	public static void one(){
		HashMap hash = new HashMap();
		hash.put(1, "green");
		System.out.println(hash);
	}
	
	public static void two(){
		HashMap hash = new HashMap();
		hash.put(1, "green");
		hash.put(2, "blue");
		hash.put(3, "orange");
		System.out.println(hash);
		int size = hash.size();
		System.out.println(size);
	}
	
	public static void three(){
		HashMap hash = new HashMap();
		hash.put(1, "green");
		hash.put(2, "blue");
		hash.put(3, "orange");
		
		Object place = hash.get(3);
		System.out.println(place);
	}
	
	public static void four(){
		HashMap hash = new HashMap();
		hash.put(1, "green");
		hash.put(2, "blue");
		hash.put(3, "orange");
		
		Object codes = hash.keySet();
		System.out.println(codes);
	}
	
	public static void five(){
		HashMap hash = new HashMap();
		hash.put(1, "green");
		hash.put(2, "blue");
		hash.put(3, "orange");
		
		Object collection = hash.values();
		System.out.println(collection);
	}
}
