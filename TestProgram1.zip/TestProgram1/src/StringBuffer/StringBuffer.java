package StringBuffer;
import java.util.Scanner;
import java.util.Stack;

public class StringBuffer {
	public static void main(String args[]){
			
		seven("abcbcb*d");
		seven("ab*cd");
		seven("ddddd*D*D***D");
		seven("ssw**");
	}
	public static void one(){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a string");
		String input = scanner.nextLine();
		String reverse = new StringBuilder(input).reverse().toString();
		System.out.println(input + " reversed is: " + reverse);
		if(input.equals(reverse)){
			System.out.println("It is a palindrome");
		}
	}
	public static void two(){
		String string1 = "RaCeCaR";
		String string2 = "rAcEcAr";
		String lowString1 = string1.toLowerCase();
		String lowString2 = string2.toLowerCase();
		char lastChar = lowString1.charAt(lowString1.length()-1);
		char firstChar = lowString2.charAt(0);
		if(lastChar!=firstChar){
			System.out.println(lowString1+lowString2);
		}else{
			System.out.println(lowString1+lowString2.substring(1));
		}
	}
	public static void three(String input){
		String firstTwo = input.substring(0, 2);
		for(int i=0; i<input.length(); i++){
			System.out.print(firstTwo);
		}
	}
	public static String four(String input){
		int stringLength = input.length();
		if(stringLength%2==0){
			System.out.println(input.substring(0, (stringLength/2)));
		}else{
			System.out.println("null");
		}
		return input;
	}
	public static void five(String input){
		String output = input.substring(1, input.length()-1);
		System.out.println(output);
	}
	public static void six(String input){
		input = input.toLowerCase();
		String checkr = "x";
		if(input.startsWith(checkr)){
			input=input.substring(1);
		}
		if(input.endsWith(checkr)){
			input=input.substring(0, input.length()-1);
		}
		System.out.println(input);
	}
	public static void seven(String input){
		//create new stack
		Stack<String> stack = new Stack<String>();
		//loops through input up to length
		for(int i=0; i<input.length(); i++){
			//if character at i is not equal to * (side note "" is for string and '' is for char)
			if(input.charAt(i)!='*'){
				//push char onto stack, transforming it into string through concatenation
				stack.push(input.charAt(i)+"");
				//else if character is a star
			}else{
				//if stack isn't empty
				if(!stack.isEmpty()){
					//if char at i-1 wasn't a star then pop it
					if(input.charAt(i-1)!='*'){
						stack.pop();
					}	
					//if next char is a star and it's not the last star then proceed
					if(input.charAt(i+1)=='*' && (i<input.length()-2)){
						//if the next character is a star and the character after it isn't
						if(input.charAt(i+1)=='*' && input.charAt(i+2)!='*'){	
							i++;
						}
					}					
					i++;
				}
			}
		}
		System.out.println(stack);		
	}
	public static void eight(String input, String input2){
		String string1 = input;
		String string2 = input2;
		String longestWord;
		String shortestWord;
		
		if(string1.length()<string2.length()){
			longestWord = string2;
			shortestWord = string1;
		}else{
			longestWord = string1;
			shortestWord = string2;
		}	
		
		for (int i = 0; i < longestWord.length(); i++) {
			System.out.print(longestWord.charAt(i));
			if(shortestWord.length()>i){
				System.out.print(shortestWord.charAt(i));				
			}
		}
	}
	
	public static void nine(String stringInput, int intInput){
		String repeatString = stringInput.substring((stringInput.length()-intInput));
		for(int i=0; i<intInput; i++){
			System.out.print(repeatString);
		}
	}
}
