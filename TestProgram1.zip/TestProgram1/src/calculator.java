
public class calculator {

	public static int powerInt(int num1, int num2){
		int powerOf = (int) Math.pow(num1, num2);	
		return powerOf;
	}
	
	public static double powerDouble(double num1, double num2){
		double powerOf = Math.pow(num1, num2);
		return powerOf;
	}
	
}
