
public class newCalc {

	public static void main(String[] args) {
		System.out.println(calculator.powerInt(3, 2));

	}

}
