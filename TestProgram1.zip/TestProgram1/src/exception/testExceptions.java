package exception;

import java.util.Scanner;

import javax.jws.Oneway;

public class testExceptions {

		public static void main(String[] args){
			two();
		}
		
		public static void one(){
			Scanner scanner = new Scanner(System.in);
			System.out.println("Please enter a string");
			String input = scanner.nextLine();
			
			try{
				int parsed = Integer.parseInt(input);
				System.out.println(parsed);
				int squared = parsed*parsed;
				System.out.println(squared);
			}catch(NumberFormatException e){
				System.out.println("NOT A GODDAMN NUMBER");
			}
		}
		
		public static void two(){
			System.out.println("Please enter an integer");
			Scanner scanner = new Scanner(System.in);
			int arraySize = scanner.nextInt();
			int newArray[] = new int[arraySize];
			
			for(int i=0; i<newArray.length; i++){
				System.out.println("Please enter an integer");
				newArray[i] = scanner.nextInt();
			}
			System.out.println("Please enter the index you wish to see");
			int index = scanner.nextInt();
			
			try{
				System.out.println(newArray[index]);
			}catch(ArrayIndexOutOfBoundsException e){
				System.out.println("Array Index Out of Bounds");
			}
			
		}
		
}
