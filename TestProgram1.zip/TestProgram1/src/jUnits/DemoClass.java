package jUnits;

public class DemoClass {

	public String stringConcat(String x, String y){
		return x+y;
		
	}
	
}
