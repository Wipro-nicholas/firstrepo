package jUnits;

import static org.junit.Assert.*;

import org.junit.Test;

public class AllTests {

	@Test
	public void testStringConcat() {
		DemoClass tester = new DemoClass();
		String output = tester.stringConcat("Hello, ", "Darling");
		assertEquals("Hello, Darling", output);
		
	}

}
