
public class box {

	double width;
	double height;
	double depth;
	double volume;
	
	//getters
	public double getWidth(){
		return width;
	}
	
	public double getHeight(){
		return height;
	}
	
	public double getDepth(){
		return depth;
	}
	
	//setters
	public void setWidth(double setWidth){
		width=setWidth;
	}
	
	public void setHeight(double setHeight){
		height=setHeight;
	}
	
	public void setDepth(double setDepth){
		depth=setDepth;
	}
	
	public double getVolume(){
		
		return volume;
	}
}
