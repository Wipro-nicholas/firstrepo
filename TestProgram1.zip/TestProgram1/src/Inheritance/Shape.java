package Inheritance;


public class Shape {

	public static void main(String[] args) {
		Shape c=new Circle ();
		Shape t=new Triangle ();
		Shape s=new Square ();
	}
	
	public Shape(){
		draw();
		erase();
	}

	public void draw(){
		System.out.println("Drawing Shape");
	}
	public void erase(){
		System.out.println("Erasing Shape");
	}


}
