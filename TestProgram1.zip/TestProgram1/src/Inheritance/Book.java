package Inheritance;

public class Book {

	private String bookTitle;
	private String author;
	private String isbnCode;
	private double originalPrice;
	private double finalPrice;
	
	public Book(){
		
	}	
	
	
	public static void main(String[] args) {
		Book faggot = new Book("faggot","faggoto","fsdfg",5.99,5.99);
		System.out.println(faggot.getFinalPrice());
		System.out.println(faggot.getDiscountedPrice(4545843));
	}
	
	
	
	
	
	
	
	
	
	
	public Book(String bookTitle, String author, String isbnCode,
			double originalPrice, double finalPrice) {
		//super();
		this.bookTitle = bookTitle;
		this.author = author;
		this.isbnCode = isbnCode;
		this.originalPrice = originalPrice;
		this.finalPrice = finalPrice;
	}
	public Book(String bookTitle, String author) {
		//super();
		this.bookTitle = bookTitle;
		this.author = author;
	}
	public Book(String isbnCode, double originalPrice, double finalPrice) {
		//super();
		this.isbnCode = isbnCode;
		this.originalPrice = originalPrice;
		this.finalPrice = finalPrice;
	}
	
	public double getDiscountedPrice(String nationalInsurance){
		finalPrice = originalPrice*0.9;
		return finalPrice;
	}
	public double getDiscountedPrice(int employeeNum){
		finalPrice = originalPrice*0.8;
		return finalPrice;
	}
	

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getIsbnCode() {
		return isbnCode;
	}

	public void setIsbnCode(String isbnCode) {
		this.isbnCode = isbnCode;
	}

	public double getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(int originalPrice) {
		this.originalPrice = originalPrice;
	}

	public double getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}


	
}
