package Inheritance;


public class Square extends Shape{

	public Square(){
		super();
	}
	public void draw(){
		System.out.println("Drawing Square");
	}
	public void erase(){
		System.out.println("Erasing Square");
	}
}
