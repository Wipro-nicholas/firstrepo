package Interfaces;

public interface LibraryUser {

	void registerAccount();
	
	void requestBook();
	
	
}
