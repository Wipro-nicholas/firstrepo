package InputoOutput;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Readerz {

	public static void main(String[] args) {
		File f = new File("txt.txt");
		String input = "txt.txt";
		String copy = "txt2.txt";
		try {
			four();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void one(File f) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(f));
		String line;
		while((line = reader.readLine())!= null){
			System.out.println(line);
		}
	}
	public static void two(File f) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(f));
		int count = 0;
		int character;
		
		while((character = reader.read())!= -1){
			if(character == 'a' || character == 'A'){
				count++;
			}
		}
		System.out.println(count);
	}
	public static void three(String input, String copy) throws FileNotFoundException, IOException {
		 Files.copy(Paths.get(input), new FileOutputStream(copy));
		 File f = new File("txt2.txt");
		 BufferedReader reader = new BufferedReader(new FileReader(f));
			String line;
			while((line = reader.readLine())!= null){
				System.out.println(line);
			}
	}
	
	public static void four() throws IOException {
		InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(new File("testImage.jpg"));
            os = new FileOutputStream(new File("copyImage.jpg"));
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
	}
}
