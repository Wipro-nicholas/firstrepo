package GroupProject;

import java.util.Random;

public class Matrix {
	
	
	public static void main(String args[]){
		matrix();
	}
	public static void matrix() {
		int[][] dArray = {{1,2,9},{3,5,8},{6,7,4}};
		
		/*
		int [][] dArray = new int[3][3];
		Random r = new Random();
		for(int i = 0; i<3; i++){
			for(int j=0; j<3; j++){
				int value = r.nextInt(9)+1;
				dArray[i][j] = value;
			}
		}
		*/
		int sumCorner = (dArray[0][0] + dArray[2][2] + dArray[0][2] + dArray[2][0]);
		int sumMid = (dArray[0][1] + dArray[1][0] + dArray[1][2] + dArray[2][1]);
		System.out.println(sumMid);
		System.out.println(sumCorner);
		
		if(sumCorner > sumMid){
			System.out.println("This matrix is corner heavy");
		}else if(sumMid > sumCorner){
			System.out.println("This matrix is mid heavy");
		}else{
			System.out.println("This matrix is balanced");
		}
	}
	
	
	
}
