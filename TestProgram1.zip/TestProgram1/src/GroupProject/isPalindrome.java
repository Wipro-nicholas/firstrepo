package GroupProject;

public class isPalindrome {

	public static void main(String[] args) {
		isPalindrome("AbBA");
	}
	
	public static void isPalindrome(String input1) {
		int output1 = 2;		
		String reverse = new StringBuilder(input1).reverse().toString();
		System.out.println("1 = Palindrome, 2 = Not");
		if(input1.equalsIgnoreCase(reverse)){
			output1 = 1;
			System.out.println(output1);
		}else{
			System.out.println(output1);
		}
	}
}
