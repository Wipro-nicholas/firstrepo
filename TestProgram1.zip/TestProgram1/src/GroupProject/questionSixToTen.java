package GroupProject;

import java.util.Random;
import java.util.Scanner;

public class questionSixToTen {

	
	public static void main(String[] args) {		
		createPin();
	}
	
	public static void longestIncreasingSeq(int input1, int[] input2) {
		int count = 1;
		int max = 1;
		for(int i=1; i<input2.length; i++){
			if(input2[i]>input2[i-1]){
				count++;
				if(count>max){
					max=count;
				}
			}else{
				count = 1;
			}			
		}
		System.out.println(max);
	} 
	
	public static void createPin() {
		int alpha = 1234;		//get units
		int beta = 10;			//get tens
		int gamma = 9610000;		//get hundreds
		int total = 0;
		
		//hundreds
		if(gamma <=99){
			if(gamma%10!=0){
				total += (100*(gamma%10));
			}else{
				total += 900;
			}
		}else{
			gamma = gamma/10;
			gamma = gamma/10;
			gamma = gamma%10;
			if(gamma!=0){
				total += gamma*100;
			}else{
				total += 900;
			}
		}
		//tens
		if(beta<10){
			beta = beta*10;
			total += beta;
		}else{
			beta = beta/10;	
			beta = beta%10;
			total += (beta*10);
		}
		//units
		total += alpha%10;
		System.out.println(total);
	}	
	
	static void reverseOptions(String input){
		Scanner scanner = new Scanner(System.in);
		int option = scanner.nextInt();
		
		switch(option){
		case 0:
		}
	}
	
}
