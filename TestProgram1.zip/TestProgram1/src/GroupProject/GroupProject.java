package GroupProject;

import java.util.concurrent.TimeUnit;

public class GroupProject {
	
	public static void main(String[] args) throws InterruptedException{
		modulo(254, 209);	
	}
	
	public static void modulo(int i, int j) {
		int modulo1 = i%10;
		int modulo2 = j%10;
		
		int sum = modulo1 + modulo2;
		System.out.println(sum);
	}
	
	public static void digiSum(int input) throws InterruptedException{
		int digiSum = 0;
		String string = input+"";
		boolean positive =true;
		if(input<0){
			digiSum = input * -1;
			string = digiSum + "";
			positive = false;
		}
		do{
			digiSum=0;
			for(int i=0; i<string.length(); i++){
				digiSum += Integer.parseInt(string.charAt(i)+"");
			}
			string=digiSum+"";
			
			TimeUnit.SECONDS.sleep(1);
		}while(digiSum>9);
		System.out.println(positive);
		System.out.println(digiSum);
		if(positive==false){
			digiSum = digiSum * -1;
		}
		System.out.println(digiSum);
	}
	
    public static void getReverseInt(int value, int value2, int value3) {
    	boolean bool1 = false, bool2 = false, bool3 = false; 
    	int reverseNum;
		int totalNum = 0;
    	boolean boolArray[] = {bool1, bool2, bool3};
    	
    	int numberArray[] = {value, value2, value3};
    	int total = 0;  
    	
    	for(int k=0; k<numberArray.length; k++){
    		if(numberArray[k]<0){
    			numberArray[k] = numberArray[k] *-1;
    			boolArray[k] = true;
    		}
    	}    
    	
    	for(int j=0; j<numberArray.length; j++){
    		String number = Integer.toString(numberArray[j]);
    		String output = "";
    		int sum = 0;
    		for(int i = number.length()-1; i >= 0; i--){
    	        	output += number.charAt(i);
    	        	sum = Integer.parseInt(output);
    	    }
    		if(boolArray[j]){
	        	sum = sum *-1;
	        }
	        System.out.println(sum);
    		total += (sum);
     	}   	
    	
    	if(total > 0){
    		String stringTotal = new StringBuilder(total).reverse().toString();
    	}else{
    		total *= -1;    		
    		while(total>0){
    			reverseNum = total%10;
    			total = total / 10;
    			totalNum = totalNum * 10 + reverseNum;
    		}
    		totalNum *= -1;
    	} 	
    	System.out.println(totalNum);
    }
}
