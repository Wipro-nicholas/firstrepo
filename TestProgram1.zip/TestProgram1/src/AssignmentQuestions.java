import java.util.Arrays;
import java.util.Scanner;
public class AssignmentQuestions {
	static String string1 = null;
	static String string2 = null;
	static int int1;
	static int int2;
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		int question;		
		System.out.println("Question?");
		question = scanner.nextInt();
		//switch statement to hold each question
		switch (question){	
		case 1: one(); 
			break;			
		case 2:	two(); 
			break;
		case 3: three();	
			break;
		case 4: four();	
			break;
		case 5: five(); 
			break;
		case 6: six(); 
			break;
		case 7: seven();	
			break;
		case 8: eight();	
			break;
		case 9: nine();
			break;
		case 10: ten();
			break;
		case 11: eleven();
			break;
		case 12: twelve();
			break;
		case 13: thirteen();
			break;
		case 14: fourteen();
			break;
		case 15: fifteen();
			break;
		case 16: sixteen();
			break;
		default: System.out.println("You didn't provide a valid question number");
			break;
		}
	}
	
	public static void one(){
		askForString();
		System.out.println("If we add your 2 strings together we get: ");
		System.out.println(string1 + " " + string2);
	}
	
	public static void two(){
		askForString();
		if(string1.equals(string2)){
			System.out.println("The 2 strings are the same");
		}else{
			System.out.println("The 2 strings are not the same");
			System.out.println("String 1: " + string1);
			System.out.println("String 2: " + string2);
		}
	}
	
	public static void three(){
		askForString();
		String reverse = new StringBuffer(string2).reverse().toString();
		System.out.println(string1 + " " + reverse);
	}
	
	public static void four(){
		askForInt();
		int total = int1 + int2;
		System.out.println("The sum of " + int1 + " and " + int2 + " is " + total );
	}
	
	public static void five(){
		System.out.println("Please enter a number");
		int1 = scanner.nextInt();
		if(int1 > 0){
			System.out.println("Your number is positive");	
		}else if(int1 < 0){
			System.out.println("Your number is negative");
		}else{
			System.out.println("Your number is 0");
		}
	}
	
	public static void six(){
		askForInt();
		if(int1 > int2){
			for(int i=int2; i < int1; i++){
				if(i%2==0){
					System.out.println(i);
				}
			}
		}else{
			for(int i=int1; i < int2; i++){
				if(i%2==0){
					System.out.println(i);
				}
			}
		}
	}
	
	public static void seven(){
		int k =0;
	    int num =0;
	    askForInt();			    
	    String  primeNumbers = "";
       	for (k = int1; k <= int2; k++){ 		  	  
	    	int counter=0; 	  
	        for(num =k; num>=1; num--){
	        	if(k%num==0){
	        	counter = counter + 1;
	        	}
	        }
	        if (counter ==2){
	        	primeNumbers = primeNumbers + k + " ";
		  }	
       	}	
	    System.out.println("Prime numbers from "+ int1 +" to " + int2 + " are :");
	    System.out.println(primeNumbers);
	}
	
	public static void eight(){
		String case1 = "The interest rate is 8.2%, if gender is Female and Age is between 1 to 58";
		String case2 = "The interest rate is 7.6%, if gender is Female and Age is between 59 to 120";
		String case3 = "The interest rate is 9.2%, if gender is Male and Age is between 1 to 60";
		String case4 = "The interest rate is 8.3%, if gender is Male and Age is between 61 to 120";
		
		System.out.println("Please Enter Your Gender");
		string1 = scanner.nextLine();
		string1 = scanner.nextLine();
		System.out.println("Please Enter Your Age");
		int1 = scanner.nextInt();
		if(string1.equals("Male") && int1 > 60 && int1<120){
			System.out.println(case4);
		}else if(string1.equals("Male") && int1 < 61){
			System.out.println(case3);
		}else if(string1.equals("Female") && int1 > 60 && int1<120){
			System.out.println(case2);
		}else{
			System.out.println(case1);
		}
	}
	
	public static void nine(){
		int monthNumber = 0;
		String month;
		System.out.println("Enter a Number");
		monthNumber = scanner.nextInt();
		switch(monthNumber){
        case 1: month = "January";
            break;
        case 2: month = "February";
            break;
        case 3: month = "March";
            break;
        case 4: month = "April";
            break;
        case 5: month = "May";
            break;
        case 6: month = "June";
            break;
        case 7: month = "July";
            break;
        case 8: month = "August";
            break;
        case 9: month = "September";
            break;
        case 10: month = "October";
            break;
        case 11: month = "November";
            break;
        case 12: month = "December";
            break;
        default:
        	month = "invalid number code";
        	break;
		}
        System.out.println(month);
	}
	
	public static void ten(){
		System.out.println("Please enter a number");
		int1 = scanner.nextInt();
		int palindrome = int1;
		int reverse1 = 0;				
		while(palindrome != 0){
			int remainder = palindrome % 10;
			reverse1 = reverse1 * 10 + remainder;
			palindrome = palindrome / 10;
		}
		if(int1 == reverse1){
			System.out.println(int1 + " is a palindrome");
		}			
	}
	
	public static void eleven(){
		System.out.println("11");
		int i=0;
		int count = 1;
		while(i<5){
			count++;
			if(count%2==0){
				if(count%3 == 0){
					if(count%5 == 0){
						System.out.println(count + "ez");
						i++;
					}
				}
			}
		}
	}
	
	public static void twelve(){
		int choiceNumber = 0;
		System.out.println("Pick an Option: (1 or 2)");
		System.out.println("1: Add");
		System.out.println("2: Subtract");
		choiceNumber = scanner.nextInt();
		switch(choiceNumber){
        case 1:
            //Addition
        	askForInt();
        	int total = int1+int2;
        	System.out.println(total);
            break;
        case 2:
            //Subtract
        	askForInt();
            total = int1-int2;
            System.out.println(total);
            break;
        default:
            System.out.println("Oops, you didn't press a number linked to an option");
            break;
		}
	}
	
	public static void thirteen(){
		int[] data = new int[] {10,20,30,40,50,660,1,80,90,91};
		int minValue = data[0];
		int maxValue = data[0];
		
		for(int i=0; i<data.length; i++){
			if(data[i]<minValue){
				minValue = data[i];
			}
			if(data[i]>maxValue){
				maxValue = data[i];
			}
		}
		System.out.println("The max value in the array is: ");
		System.out.println(maxValue);
		System.out.println("The min value in the array is: ");
		System.out.println(minValue);
	}
	
	public static void fourteen(){
		boolean found = false;
		System.out.println("Please enter a number");
		int1 = scanner.nextInt();
		int[] checkArray = new int[] {2,4,6,8,10};
		for(int i=0; i<checkArray.length; i++ ){
			if(int1 == checkArray[i]){
				System.out.println(checkArray[i]);
				found = true;
			}
		}
		if(!found){
			System.out.println("-1");
		}
	}
	
	public static void fifteen(){
		int[] input = new int[]{1, 1, 3, 7, 7, 8, 9, 9, 9, 10};
		Arrays.sort(input);
		int current = input[0];
		boolean found = false;

		for (int i = 0; i < input.length; i++) {
		    if (current == input[i] && !found) {
		        found = true;
		    } else if (current != input[i]) {
		        System.out.print(" " + current);
		        current = input[i];
		        found = false;
		    }
		}
		System.out.print(" " + current);
	}
	
	public static void sixteen(){
		int modeArray[] = new int[] {1,2,3,4,5,6,7,7,8,9,10,10,10,10,11,12,13};
		Arrays.sort(modeArray);
		int count1 = 0;
		int count2 = 0;
		int popNumber = 0;
		int popNumberStore = 0;		
		for(int i=0; i<modeArray.length; i++){
			popNumber = modeArray[i];
			count1=0;			
			for(int j=i+1; j<modeArray.length;j++){
				if(popNumber ==modeArray[j]){
					count1++;
				}
				if(count1>count2){
					popNumberStore = popNumber;
					count2 = count1;
				}else if(count1==count2){
					popNumberStore = Math.min(popNumberStore, popNumber);
				}
			}
		}
		System.out.println(popNumberStore);
	}

	public static void askForString(){
		//this first nextLine() is used to hold the new line which is input when entering the question
		string1 = scanner.nextLine();	
		System.out.println("Please enter a string");
		string1 = scanner.nextLine();				
		System.out.println("Please enter another string");
		string2 = scanner.nextLine();
	}
	
	public static void askForInt(){
		System.out.println("Please enter a Number");
		int1 = scanner.nextInt();				
		System.out.println("Please enter another Number");
		int2 = scanner.nextInt();
	}	
}