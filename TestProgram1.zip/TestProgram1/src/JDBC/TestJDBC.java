package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = connect();
		
		
		

	}
	
	public static Connection connect(){
		Connection conn = null;
		try {
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl1","scott","tiger");
			System.out.println("Connected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed to Connect");
		}
		return conn;
	}
	
	public static void one(Connection conn) throws SQLException{
		Statement command = conn.createStatement();
		String sql = "SELECT empno, ename FROM emp";
		ResultSet results = command.executeQuery(sql);
		
		while(results.next()){
			int empNum = results.getInt("empno");
			String name = results.getString("ename");
			
			System.out.println("Employee Number: " + empNum);
			System.out.println("Employee Name: " + name);
			System.out.println();			
		}
	}
	
	public static void two(Connection conn) throws SQLException{
		Statement command = conn.createStatement();
		String sql = "SELECT empno, ename, sal, comm FROM emp WHERE sal > 1000 AND sal < 2000";
		ResultSet results = command.executeQuery(sql);
		
		while(results.next()){
			int empNum = results.getInt("empno");
			String name = results.getString("ename");
			int sal = results.getInt("sal");
			int comm = results.getInt("comm");
			
			System.out.println("Employee Number: " + empNum);
			System.out.println("Employee Name: " + name);
			System.out.println("Employee Comm: " + comm);
			System.out.println("Employe Salary: " + sal);
			System.out.println();			
		}
	}
	
	public static void three(Connection conn) throws SQLException{
		Statement insertCommand = conn.createStatement();
		String sqlInsert = "INSERT INTO emp  ";
		
	}

}
